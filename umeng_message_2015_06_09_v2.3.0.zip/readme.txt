友盟 Android SDK 文档(中文)：
http://dev.umeng.com/message/android/integration-guide
